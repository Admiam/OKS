package oks02;

public class Hlavni {
  public static void main(String[] args) {
    OsobniCislo oc = new OsobniCislo("Novák, Josef, fav, 2014, b, 0123, p, i");
    System.out.println(oc);
  }
}
